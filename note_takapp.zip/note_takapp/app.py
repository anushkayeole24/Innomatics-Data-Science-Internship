from flask import Flask, request, render_template
app = Flask(__name__)
notes = []
@app.route('/')
def index():
    #note = request.args.get("note")
    #notes.append(note)
    return render_template("home.html")
@app.route('/thank',methods=[''])
def thank():
    note = request.form.get("note")
    notes.append(note)
    return render_template("thank.html", notes=notes)
if __name__ == "__main__":
    app.run(debug=True)